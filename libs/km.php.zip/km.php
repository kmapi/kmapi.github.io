<?php

/**
 *
 * @package Model
 */
class Km
{
	private $token;
	private $api_url = 'http://devapi.kitchenmonki.com/v2';

	/**
	 * @param $token
	 * @return mixed
	 */
	public function setToken($token)
	{
		$this->token = $token;
	}

	/**
	 * be sure to set the token before calling the api
	 *
	 * @param $params - required values in $params: path, method
	 * @return mixed
	 */
	public function api($params)
	{
		$path = $params['path'];
		unset($params['path']);
		$method = strtoupper($params['method']);
		unset($params['method']);

		$uri = $this->api_url.$path;
		$ch = curl_init($uri);
		curl_setopt($ch, CURLOPT_TIMEOUT, 300);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array("Authorization: Bearer {$this->token}",
			"X-HTTP-Method-Override: {$method}"));
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
		$response = curl_exec($ch);
		curl_close($ch);

		return $response;
	}

	/**
	 * @param $client_id
	 * @param $client_secret
	 * @return mixed
	 */
	public function getClientToken($client_id, $client_secret)
	{
		$uri = $this->api_url.'/token/grant?grant_type=client_credentials&client_id='.
			$client_id.'&client_secret='.$client_secret;

		$ch = curl_init($uri);
		curl_setopt($ch, CURLOPT_TIMEOUT, 300);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-HTTP-Method-Override: GET'));
		$response = curl_exec($ch);
		curl_close($ch);

		return $response;
	}

	/*
	 * ---------------------------------------------------------------------------
	 *
	*/

	/**
	 * @return mixed
	 */
	public function createUser()
	{
		$user = self::api(array(
			'method' => 'post',
			'path' => '/user'
		));

		return $user;
	}

	/**
	 * @param $user_id
	 * @return mixed
	 */
	public function getUser($user_id)
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => '/user/'.$user_id,
		));

		return $result;
	}

	/**
	 * @return mixed
	 */
	public function getAllUsers()
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => '/user/all',
		));

		return $result;
	}

	/**
	 * @param $id
	 * @return mixed
	 */
	public function getUserFriends($id)
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => "/user/{$id}/friends",
		));

		return $result;
	}

	/**
	 * @param $id
	 * @return mixed
	 */
	public function getUserFollowers($id)
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => "/user/{$id}/followers",
		));

		return $result;
	}

	/**
	 * @param $id
	 * @return mixed
	 */
	public function getUserFollowing($id)
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => "/user/{$id}/following",
		));

		return $result;
	}

	/**
	 * @param $user_id
	 * @param $follow_user_id
	 * @return mixed
	 */
	public function followUser($user_id, $follow_user_id)
	{
		$result = self::api(array(
			'method' => 'post',
			'path' => "/user/{$user_id}/following/{$follow_user_id}",
		));

		return $result;
	}

	/**
	 * @param $user_id
	 * @param $follow_user_id
	 * @return mixed
	 */
	public function stopFollowingUser($user_id, $follow_user_id)
	{
		$result = self::api(array(
			'method' => 'delete',
			'path' => "/user/{$user_id}/following/{$follow_user_id}",
		));

		return $result;
	}

	/**
	 * @param $user_id
	 * @param $data
	 * @return mixed
	 */
	public function updateUser($user_id, $data)
	{
		$result = self::api(array(
			'method' => 'put',
			'path' => '/user/'.$user_id,
			'data' => json_encode($data),
		));

		return $result;
	}

	/**
	 * @param $user_id
	 * @return mixed
	 */
	public function deleteUser($user_id)
	{
		$result = self::api(array(
			'method' => 'delete',
			'path' => '/user/'.$user_id,
		));

		return $result;
	}

	/**
	 * @return mixed
	 */
	public function createRecipe()
	{
		$recipe = self::api(array(
			'method' => 'post',
			'path' => '/recipe'
		));

		return $recipe;
	}

	/**
	 * @param $user_id
	 * @return mixed
	 */
	public function getRecipe($user_id)
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => '/recipe/'.$user_id
		));

		return $result;
	}

	/**
	 * @param $data - consists of search parameters
	 * @return mixed
	 */
	public function searchRecipes($data)
	{
		$data['method'] = 'get';
		$data['path'] = '/recipe/search';
		$result = self::api($data);

		return $result;
	}

	/**
	 * @param $id
	 * @param $data - consists of recipe properties to update in key value pairs
	 * @return mixed
	 */
	public function updateRecipe($id, $data)
	{
		$result = self::api(array(
			'method' => 'put',
			'path' => '/recipe/'.$id,
			'data' => json_encode($data)
		));

		return $result;
	}

	/**
	 * @param $recipe_id
	 * @return mixed
	 */
	public function publishRecipe($recipe_id)
	{
		$result = self::api(array(
			'method' => 'put',
			'path' => '/recipe/'.$recipe_id.'/publish',
		));

		return $result;
	}

	/**
	 * @param $recipe_id
	 * @return mixed
	 */
	public function deleteRecipe($recipe_id)
	{
		$result = self::api(array(
			'method' => 'delete',
			'path' => '/recipe/'.$recipe_id
		));

		return $result;
	}

	/**
	 * @param $recipe_id
	 * @param $data - consists of recipe step data parameters in key value pairs
	 * @return mixed
	 */
	public function addRecipeStep($recipe_id, $data)
	{
		$data['method'] = 'post';
		$data['path'] = '/recipe/'.$recipe_id.'/step';

		$result = self::api($data);

		return $result;
	}

	/**
	 * @param $recipe_id
	 * @param $step_id
	 * @return mixed
	 */
	public function deleteRecipeStep($recipe_id, $step_id)
	{
		$result = self::api(array(
			'method' => 'delete',
			'path' => '/recipe/'.$recipe_id.'/step/'.$step_id
		));

		return $result;
	}

	/**
	 * @param $recipe_id
	 * @param $data - consists of recipe ingredient data parameters in key value pairs
	 * @return mixed
	 */
	public function addRecipeIngredient($recipe_id, $data)
	{
		$data['method'] = 'post';
		$data['path'] = '/recipe/'.$recipe_id.'/ingredient';

		$result = self::api($data);

		return $result;
	}

	/**
	 * @param $recipe_id
	 * @param $recipe_ingredient_id
	 * @return mixed
	 */
	public function deleteRecipeIngredient($recipe_id, $recipe_ingredient_id)
	{
		$result = self::api(array(
			'method' => 'delete',
			'path' => '/recipe/'.$recipe_id.'/ingredient/'.$recipe_ingredient_id
		));

		return $result;
	}

	/**
	 * @return mixed
	 */
	public function createList()
	{
		$result = self::api(array(
			'method' => 'post',
			'path' => '/list'
		));

		return $result;
	}

	/**
	 * @param $list_id
	 * @return mixed
	 */
	public function getList($list_id)
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => '/list/'.$list_id,
		));

		return $result;
	}

	/**
	 * @param $list_id
	 * @return mixed
	 */
	public function deleteList($list_id)
	{
		$result = self::api(array(
			'method' => 'delete',
			'path' => '/list/'.$list_id,
		));

		return $result;
	}

	/**
	 * @param $list_id
	 * @param $data - consists of list item data parameters
	 * @return mixed
	 */
	public function addListItem($list_id, $data)
	{
		$data['method'] = 'post';
		$data['path'] = '/list/'.$list_id.'/item';

		$result = self::api($data);

		return $result;
	}

	/**
	 * @param $list_item_id
	 * @return mixed
	 */
	public function deleteListItem($list_item_id)
	{
		$result = self::api(array(
			'method' => 'delete',
			'path' => '/list/item/'.$list_item_id,
		));

		return $result;
	}

	/**
	 * @param $data - consist of plan request parameters
	 * @return mixed
	 */
	public function getPlan($data)
	{
		$data['method'] = 'get';
		$data['path'] = '/plan';

		$result = self::api($data);

		return $result;
	}

	/**
	 * @param $recipe_id
	 * @param $meal
	 * @param $data - consists of plan item parameters kvp
	 * @return mixed
	 */
	public function addPlanItem($recipe_id, $meal, $data)
	{
		$data['method'] = 'post';
		$data['path'] = '/plan/item';

		$data['recipe_id'] = $recipe_id;
		$data['meal'] = $meal;
		$data['date'] = !empty($data['date']) ? $data['date'] : 'today';
		$data['servings'] = !empty($data['servings']) ? $data['servings'] : 0;

		$result = self::api($data);

		return $result;
	}

	/**
	 * @param $plan_item_id
	 * @return mixed
	 */
	public function deletePlanItem($plan_item_id)
	{
		$result = self::api(array(
			'method' => 'delete',
			'path' => '/plan/item/'.$plan_item_id,
		));

		return $result;
	}

	/**
	 * @param $meal
	 * @param $text
	 * @param $data
	 * @return mixed
	 */
	public function addPlanNote($meal, $text, $data)
	{
		$data['method'] = 'post';
		$data['path'] = '/plan/note';

		$data['meal'] = $meal;
		$data['text'] = $text;
		$data['date'] = !empty($data['date']) ? $data['date'] : 'today';

		$result = self::api($data);

		return $result;
	}

	/**
	 * @param $plan_note_id
	 * @return mixed
	 */
	public function deletePlanNote($plan_note_id)
	{
		$result = self::api(array(
			'method' => 'delete',
			'path' => '/plan/note/'.$plan_note_id,
		));

		return $result;
	}

	/**
	 * @param $id
	 * @return mixed
	 */
	public function getBrandFamily($id)
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => '/brand/'.$id.'/family'
		));

		return $result;
	}

	/**
	 * @param $id
	 * @return mixed
	 */
	public function getBrandItem($id)
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => '/brand/'.$id.'/item'
		));

		return $result;
	}

	/**
	 * @param $name
	 * @return mixed
	 */
	public function createBrandFamily($name)
	{
		$result = self::api(array(
			'method' => 'post',
			'path' => '/brand/family',
			'name' => $name,
		));

		return $result;
	}

	/**
	 * @param $brand_family_id
	 * @return mixed
	 */
	public function deleteBrandFamily($brand_family_id)
	{
		$result = self::api(array(
			'method' => 'delete',
			'path' => '/brand/family/'.$brand_family_id,
		));

		return $result;
	}

	/**
	 * @param $brand_family_id
	 * @param $brand_text
	 * @return mixed
	 */
	public function createBrandItem($brand_family_id, $brand_text)
	{
		$result = self::api(array(
			'method' => 'post',
			'path' => '/brand/'.$brand_family_id.'/item',
			'brand_text' => $brand_text,
		));

		return $result;
	}

	/**
	 * @param $brand_item_id
	 * @return mixed
	 */
	public function deleteBrandItem($brand_item_id)
	{
		$result = self::api(array(
			'method' => 'delete',
			'path' => '/brand/item/'.$brand_item_id,
		));

		return $result;
	}

	/**
	 * @return mixed
	 */
	public function getAllBrands()
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => '/brand/all',
		));

		return $result;
	}

	/**
	 * @param $location_id
	 * @return mixed
	 */
	public function getLocation($location_id)
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => '/location/'.$location_id,
		));

		return $result;
	}

	/**
	 * @return mixed
	 */
	public function getAllLocations()
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => '/location/all',
		));

		return $result;
	}

	/**
	 * @param $name
	 * @param $zip
	 * @return mixed
	 */
	public function createLocation($name, $zip)
	{
		$result = self::api(array(
			'method' => 'post',
			'path' => '/location',
			'name' => $name,
			'zip' => $zip,
		));

		return $result;
	}

	/**
	 * @param $location_id
	 * @param $data - consists of updated location values in kvp
	 * @return mixed
	 */
	public function updateLocation($location_id, $data)
	{
		$data['method'] = 'put';
		$data['path'] = '/location/'.$location_id;

		$result = self::api($data);

		return $result;
	}

	/**
	 * @param $store_id
	 * @return mixed
	 */
	public function getStore($store_id)
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => '/store/'.$store_id,
		));

		return $result;
	}

	/**
	 * @param $store_id
	 * @param $location_id
	 * @return mixed
	 */
	public function addStoreToLocation($store_id, $location_id)
	{
		$result = self::api(array(
			'method' => 'post',
			'path' => '/store',
			'store_id' => $store_id,
			'location_id' => $location_id,
		));

		return $result;
	}

	/**
	 * @param $store_id
	 * @param $location_id
	 * @return mixed
	 */
	public function setStoreAsDefault($store_id, $location_id)
	{
		$result = self::api(array(
			'method' => 'put',
			'path' => '/store/'.$store_id,
			'store_id' => $store_id,
			'location_id' => $location_id,
		));

		return $result;
	}

	/**
	 * @param $text
	 * @return mixed
	 */
	public function searchStores($text)
	{
		$result = self::api(array(
			'method' => 'get',
			'path' => '/store/search',
			'text' => $text,
		));

		return $result;
	}

}
